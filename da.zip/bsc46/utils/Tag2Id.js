function getHLid(Hashtag) {
    var CharIndex, Character, HighLow, Id, TagArray, TagChar;
    TagChar = ["0", "2", "8", "9", "P", "Y", "L", "Q", "G", "R", "J", "C", "U", "V"];
  
    if (!Hashtag.startswith("#")) {
      return [0, 0];
    }
  
    TagArray = list(Hashtag.slice(1).upper());
    Id = 0;
  
    for (var i = 0, _pj_a = TagArray.length; i < _pj_a; i += 1) {
      Character = TagArray[i];
  
      try {
        CharIndex = TagChar.index(Character);
      } catch (e) {
        if (e instanceof ValueError) {
          return [0, 0];
        } else {
          throw e;
        }
      }
  
      Id *= TagChar.length;
      Id += CharIndex;
    }
  
    HighLow = [];
    HighLow.append(Id % 256);
    HighLow.append(Id - HighLow[0] >> 8);
    return HighLow;
  }