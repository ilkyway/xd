global.Id2Tag = {
    getHashtagfromId: function(Id = null) {
    var TagChar = ("0", "2", "8", "9", "P", "Y", "L", "Q", "G", "R", "J", "C", "U", "V");
	var Tag = [];
    while (Id > 0) {
        var CharIndex = math.floor(Id % TagChar.length);
        Tag.insert(0, TagChar[CharIndex]);
        Id -= CharIndex;
        Id /= TagChar.length;
      }
    
      return "".join(Tag);
    }
}

