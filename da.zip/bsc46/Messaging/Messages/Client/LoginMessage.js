var ByteStream = require("../../../DataStream/ByteStream");
module.exports = class {
    constructor() {
        this.ByteStream = new ByteStream();
    }
    encode() {
        //this.ByteStream.writeInt(10);
        //this.ByteStream.writeInt(42661217);
        //this.ByteStream.writeString('bcwgt7cknxraamn4k9ptgspep3zjpcnrga8wgedy');
		//this.ByteStream.writeInt(10);
        //this.ByteStream.writeInt(42741374);
        //this.ByteStream.writeString('fgdmyy2rr8t44r4kfef3y6tfxfecdgwmz6wtd8m6'); //shelly bot
         //this.ByteStream.writeInt(12);
         //this.ByteStream.writeInt(42729248);
         //this.ByteStream.writeString('yxew2b3dftb7h4gceacb2zrm2eyh2deybxfwbcyd'); //illka bot
		//this.ByteStream.writeInt(17);
        //this.ByteStream.writeInt(43000460);
        //this.ByteStream.writeString('f36mzhee98swctgyd86axcfwks2zccpa8njt3bpx'); // mat illki bot
		this.ByteStream.writeInt(27);
         this.ByteStream.writeInt(37951417);
         this.ByteStream.writeString('kyye6yw44jk2s8ta2h66fedyzmh4tj6yydckshz8'); //illka bot
        this.ByteStream.writeInt(46);
        this.ByteStream.writeInt(1);
        this.ByteStream.writeInt(209);
        this.ByteStream.writeString("e13eb3b80ac96ef51c3baa7eb25064aadfe00fed");

        this.ByteStream.writeString();
        this.ByteStream.writeDataReference(1, 0);
        this.ByteStream.writeString("ru-RU");
        this.ByteStream.writeString();
        this.ByteStream.writeBoolean(false);
        this.ByteStream.writeString();
        this.ByteStream.writeString();
        this.ByteStream.writeBoolean(true);
        this.ByteStream.writeString();
        this.ByteStream.writeInt(1448);
        this.ByteStream.writeVInt(0);
        this.ByteStream.writeString();

        this.ByteStream.writeString();
        this.ByteStream.writeString();
        this.ByteStream.writeVInt(0);

        this.ByteStream.writeString();
        this.ByteStream.writeString();
        this.ByteStream.writeString();

        this.ByteStream.writeString();

        this.ByteStream.writeBoolean(false);
        this.ByteStream.writeString();
        this.ByteStream.writeString();
    }
}
